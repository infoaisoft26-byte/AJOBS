import { CheckSquare } from "lucide-react";
import { getRedirectResult, signInWithCustomToken } from "firebase/auth";
import confetti from "canvas-confetti";
import React from "react";
import { useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { GoogleAuthProvider, createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup, signInWithRedirect, updateProfile } from "firebase/auth";
import { collection, getDocs, query, where } from "firebase/firestore";
import { AlertCircle, ArrowLeft, Briefcase, Building2, CheckCircle2, Eye, EyeOff, Mail, Phone, Send, Shield, ShieldCheck, User, UserPlus, X } from "lucide-react";
import { isFirebaseConfigured } from "@/firebase";
import { soundSynth } from "@/utils/audioSynth";
import { auth, db, firebaseConfigError } from "../firebase";

import { UserProfile } from "../types";
import { initializeUserCollectionsAndDocs, getOrCreateUserProfile } from "../services/dbInitService";
import { trackLeadSubmission } from "../utils/leadAttribution";
import { useToast } from "./GlobalToast";

interface AuthModalProps {
  onClose: () => void;
  onAuthSuccess: (user: UserProfile) => void;
  initialMode?: "signin" | "signup";
  initialRole?: "candidate" | "consultancy" | "employer" | "recruiter" | "admin" | "superadmin";
}

type AuthMode = "signin" | "signup" | "forgot-password" | "complete-profile" | "phone-otp";

const COUNTRY_CODES = [
  { code: "+91", label: "🇮🇳 India (+91)" },
  { code: "+1", label: "🇺🇸 USA/Canada (+1)" },
  { code: "+44", label: "🇬🇧 UK (+44)" },
  { code: "+61", label: "🇦🇺 Australia (+61)" },
  { code: "+65", label: "🇸🇬 Singapore (+65)" },
  { code: "+971", label: "🇦🇪 UAE (+971)" },
  { code: "+49", label: "🇩🇪 Germany (+49)" },
  { code: "+33", label: "🇫🇷 France (+33)" },
  { code: "+81", label: "🇯🇵 Japan (+81)" }
];

export default function AuthModal({ onClose, onAuthSuccess, initialMode = "signin", initialRole }: AuthModalProps) {
  const { showToast } = useToast();
  const [mode, setMode] = useState<AuthMode>(initialMode === "signup" ? "signup" : "signin");
  const [authMethod, setAuthMethod] = useState<"email" | "phone">("email");
  const [role, setRole] = useState<"candidate" | "consultancy" | "employer" | "recruiter" | "admin" | "superadmin">(initialRole || "candidate");
  
  // Inputs
  const [name, setName] = useState("");
  const [agencyName, setAgencyName] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  
  // Phone OTP
  const [countryCode, setCountryCode] = useState("+91");
  const [rawPhoneNumber, setRawPhoneNumber] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [phoneStep, setPhoneStep] = useState<"phone" | "code">("phone");
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const recaptchaVerifierRef = useRef<any>(null);

  const [otpDigits, setOtpDigits] = useState<string[]>(Array(6).fill(""));
  const [countdown, setCountdown] = useState(0);

  // 60-Second countdown timer for Twilio SMS resend logic
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // States
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  
  // Temp user for complete-profile flow
  const [tempFbUser, setTempFbUser] = useState<any>(null);

  // Password Reset Twilio OTP State
  const [resetMethod, setResetMethod] = useState<"email" | "phone">("email");
  const [resetPhoneStep, setResetPhoneStep] = useState<"phone" | "code">("phone");
  const [resetPhone, setResetPhone] = useState("");
  const [resetOtpCode, setResetOtpCode] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // Cleanup Recaptcha
  useEffect(() => {
    return () => {
      if (recaptchaVerifierRef.current) {
        try {
          recaptchaVerifierRef.current.clear();
        } catch (e) {
          console.error("reCAPTCHA cleanup error:", e);
        }
      }
    };
  }, []);

  // Listen for Redirect results on mount
  useEffect(() => {
    const checkRedirectResult = async () => {
      try {
        console.log("Checking for Google Auth redirect result...");
        const result = await getRedirectResult(auth);
        if (result?.user) {
          console.log("Google redirect sign-in succeeded! User:", result.user);
          setSuccess("Authenticated with Google (via Redirect) successfully!");
          await handlePostAuth(result.user);
        }
      } catch (err: any) {
        console.error("Error retrieving Google redirect sign-in result:", err);
        setError(translateError(err));
      }
    };

    if (isFirebaseConfigured) {
      checkRedirectResult();
    }
  }, []);

  const validateEmailFormat = (emailStr: string) => {
    return /\S+@\S+\.\S+/.test(emailStr);
  };

  const validatePasswordStrength = (pwd: string): { isValid: boolean; message: string } => {
    if (pwd.length < 8) {
      return { isValid: false, message: "Password must be at least 8 characters long." };
    }
    if (!/[A-Z]/.test(pwd)) {
      return { isValid: false, message: "Password must contain at least one uppercase letter." };
    }
    if (!/[a-z]/.test(pwd)) {
      return { isValid: false, message: "Password must contain at least one lowercase letter." };
    }
    if (!/\d/.test(pwd)) {
      return { isValid: false, message: "Password must contain at least one number." };
    }
    if (!/[@$!%*?&#^()_\-+=\[\]{}|\\\/.]/.test(pwd)) {
      return { isValid: false, message: "Password must contain at least one special character (e.g., @$!%*?&)." };
    }
    return { isValid: true, message: "" };
  };

  const translateError = (err: any): string => {
    // Task 8: Log the original Firebase error to browser console.
    console.error("Original Firebase Authentication Error:", err);
    
    if (!err) return "Authentication failed: No error details returned.";

    if (err.message && !err.code) {
      if (err.message.includes("passwords do not match")) return "Passwords do not match";
      if (err.message.includes("Please specify your")) return err.message;
      return err.message;
    }

    const code = err.code || "unknown-error-code";
    const message = err.message || "An unexpected error occurred.";

    // Task 7 & 9: Remove generic messages & display the exact Firebase error code in the UI.
    return `Firebase Error [${code}]: ${message}`;
  };

  // Post-authentication logic (checks Firestore profile and roles)
  const handlePostAuth = async (fbUser: any) => {
    try {
      console.log("Loading user profile for authenticated user UID:", fbUser.uid, "with role preference:", role);
      const userProfile = await getOrCreateUserProfile(fbUser, role);
      console.log("UserProfile loaded successfully:", userProfile);

      // Trigger 5D Celebratory Effects
      soundSynth.playSuccess();
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {}
      if (typeof navigator !== "undefined" && navigator.vibrate) {
        navigator.vibrate([30, 40, 30]);
      }

      onAuthSuccess(userProfile);
      onClose();
    } catch (err: any) {
      console.error("Firestore loading error:", err);
      setError("Successfully signed in, but failed to load database profile.");
    }
  };

  // Google Login
  const handleGoogleLogin = async () => {
    setError("");
    setSuccess("");
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      console.log("Initiating Google Popup Sign-In...");
      
      try {
        const result = await signInWithPopup(auth, provider);
        console.log("Google Popup Login Authenticated successfully!", result.user);
        setSuccess("Authenticated with Google successfully!");
        await handlePostAuth(result.user);
      } catch (popupErr: any) {
        console.warn("Google popup login failed/blocked, falling back to Redirect:", popupErr);
        
        if (popupErr.code === "auth/unauthorized-domain") {
          throw popupErr;
        }

        // Check for common popup blocked / iframe issues
        if (
          popupErr.code === "auth/popup-blocked" ||
          popupErr.code === "auth/iframe-auth-html-error" ||
          popupErr.message?.includes("iframe") ||
          popupErr.message?.includes("popup")
        ) {
          console.log("Triggering Google Redirect Sign-In as resilient fallback...");
          await signInWithRedirect(auth, provider);
        } else {
          throw popupErr;
        }
      }
    } catch (err: any) {
      if (err.code === "auth/unauthorized-domain" || err.message?.includes("unauthorized-domain")) {
        setError("Error: This development domain is not authorized for Google Sign-In in your Firebase Console. Please add this URL to the 'Authorized domains' list in your Firebase Authentication settings.");
      } else {
        setError(translateError(err));
      }
    } finally {
      setLoading(false);
    }
  };

  // Phone OTP - Send Code via Twilio
  // Helper: Handle individual digit inputs for OTP verification
  const handleDigitChange = (index: number, value: string) => {
    if (/^[0-9]$/.test(value) || value === "") {
      const newDigits = [...otpDigits];
      newDigits[index] = value;
      setOtpDigits(newDigits);
      
      // Auto focus to next input box if digit entered
      if (value !== "" && index < 5) {
        const nextInput = document.getElementById(`otp-input-${index + 1}`);
        nextInput?.focus();
      }
    }
  };

  // Helper: Handle backspace key on individual digit input
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      if (otpDigits[index] === "" && index > 0) {
        const newDigits = [...otpDigits];
        newDigits[index - 1] = "";
        setOtpDigits(newDigits);
        const prevInput = document.getElementById(`otp-input-${index - 1}`);
        prevInput?.focus();
      } else {
        const newDigits = [...otpDigits];
        newDigits[index] = "";
        setOtpDigits(newDigits);
      }
    }
  };

  // Helper: Handle clipboard paste on the digit inputs
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").trim();
    if (/^[0-9]{6}$/.test(pastedData)) {
      const chars = pastedData.split("");
      setOtpDigits(chars);
      document.getElementById("otp-input-5")?.focus();
    }
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!rawPhoneNumber.trim()) {
      setError("Please enter a valid phone number.");
      return;
    }

    const fullPhone = countryCode + rawPhoneNumber.trim();
    if (!/^\+[1-9]\d{1,14}$/.test(fullPhone)) {
      setError("Valid Phone Number is required. Ensure digits are correct.");
      return;
    }

    const displayName = role === "candidate" ? name : role === "consultancy" ? agencyName : role === "employer" ? companyName : name;

    setLoading(true);

    try {
      if (mode === "signup") {
        if (!displayName.trim()) {
          throw new Error(`Please specify your ${role === "candidate" ? "Full Name" : role === "consultancy" ? "Agency Name" : role === "employer" ? "Company Name" : "Admin Name"}`);
        }

        // Duplicate Phone Check
        console.log("Checking duplicate phone number in Firestore...");
        try {
          const qPhone = query(collection(db, "users"), where("phone", "==", fullPhone));
          const snapPhone = await getDocs(qPhone);
          if (!snapPhone.empty) {
            throw new Error("Phone already exists");
          }
        } catch (dbErr: any) {
          console.warn("[AuthModal] Pre-emptive duplicate phone check skipped or failed:", dbErr);
          if (dbErr.message === "Phone already exists") {
            throw dbErr;
          }
        }
      }

      console.log("Dispatching real Twilio Verify OTP request to backend for:", fullPhone);
      const res = await fetch("/api/twilio/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with Twilio OTP service backend.");
      }

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to dispatch mobile OTP.");
      }

      console.log("Twilio OTP sent successfully to:", fullPhone);
      setCountdown(60);
      setOtpDigits(Array(6).fill(""));
      setConfirmationResult({ phone: fullPhone, displayName });
      setPhoneStep("code");
      setSuccess("SMS verification code sent successfully via Twilio!");
    } catch (err: any) {
      console.error("Twilio Verify OTP dispatch failed:", err);
      setError(err.message || "Twilio Verify failed to send OTP. Please check your phone number.");
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = async () => {
    if (countdown > 0 || loading) return;
    setError("");
    setSuccess("");
    setLoading(true);

    const fullPhone = countryCode + rawPhoneNumber.trim();
    console.log("Resending real Twilio Verify OTP to:", fullPhone);

    try {
      const res = await fetch("/api/twilio/resend-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with Twilio OTP service backend.");
      }

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to resend mobile OTP.");
      }

      console.log("Twilio OTP resent successfully to:", fullPhone);
      setCountdown(60);
      setOtpDigits(Array(6).fill(""));
      setSuccess("SMS verification code resent successfully via Twilio!");
    } catch (err: any) {
      console.error("Twilio Resend OTP failed:", err);
      setError(err.message || "Failed to resend OTP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Phone OTP - Verify Code via Twilio
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const codeToVerify = otpDigits.join("").trim();
    if (!codeToVerify || codeToVerify.length !== 6) {
      setError("Please enter the 6-digit verification code.");
      return;
    }

    const fullPhone = countryCode + rawPhoneNumber.trim();
    const displayName = role === "candidate" ? name : role === "consultancy" ? agencyName : role === "employer" ? companyName : name;

    setLoading(true);

    try {
      console.log("Verifying code on backend:", codeToVerify, "for phone:", fullPhone);
      const res = await fetch("/api/twilio/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone, code: codeToVerify, preferredRole: role })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with OTP verify backend.");
      }

      const data = await res.json();
      if (!data.success) {
        console.log("OTP verification failed on backend for:", fullPhone);
        throw new Error(data.error || "Incorrect verification code.");
      }

      console.log("Signing in using backend custom auth token...");
      const userCred = await signInWithCustomToken(auth, data.customToken);
      const fbUser = userCred.user;

      console.log("Phone number confirmed! Authenticated User:", fbUser);

      if (mode === "signup") {
        console.log("Updating Firebase user profile display name:", displayName);
        if (fbUser && typeof fbUser.getIdToken === "function") {
          try {
            await updateProfile(fbUser, { displayName });
          } catch (pErr) {
            console.warn("Could not update Firebase DisplayName, non-blocking:", pErr);
          }
        }

        console.log("Initializing all 18 database collections & user doc...");
        const userProfile = await initializeUserCollectionsAndDocs(fbUser, role, displayName);
        
        // Trigger welcome SMS
        try {
          await fetch("/api/twilio/send-registration-sms", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              phone: fullPhone,
              role: role,
              name: displayName
            })
          });
        } catch (smsErr) {
          console.warn("Failed to trigger registration SMS notification:", smsErr);
        }

        setSuccess("Account registered successfully!");
        onAuthSuccess(userProfile);
        onClose();
      } else {
        setSuccess("Phone number verified successfully!");
        await handlePostAuth(fbUser);
      }
    } catch (err: any) {
      console.error("Phone verification failure:", err);
      setError(err.message || "Incorrect verification code. Please check and try again.");
    } finally {
      setLoading(false);
    }
  };

  // Forgot Password
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError("Please enter your email address to receive reset link.");
      return;
    }
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      console.log("Sending password reset email to:", email.trim());
      await sendPasswordResetEmail(auth, email.trim());
      setSuccess("A password reset link has been dispatched to your email address!");
    } catch (err: any) {
      setError(translateError(err));
    } finally {
      setLoading(false);
    }
  };

  // Twilio SMS Password Reset - Send OTP
  const handleSendResetOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!resetPhone.trim()) {
      setError("Please enter your registered mobile number.");
      return;
    }

    const fullPhone = resetPhone.trim().startsWith("+") ? resetPhone.trim() : "+91" + resetPhone.trim();
    if (!/^\+[1-9]\d{1,14}$/.test(fullPhone)) {
      setError("Valid Phone Number is required. Ensure digits are correct.");
      return;
    }

    setLoading(true);

    try {
      console.log("Sending Twilio Password Reset OTP to:", fullPhone);
      const res = await fetch("/api/twilio/send-reset-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with Twilio Password Reset OTP service.");
      }

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to dispatch password reset OTP.");
      }

      setResetPhoneStep("code");
      setSuccess(data.message || "Password reset OTP dispatched to your mobile number!");
    } catch (err: any) {
      console.error("Password reset OTP dispatch failed:", err);
      setError(err.message || "Failed to dispatch password reset OTP. Please check your network connection and configuration.");
    } finally {
      setLoading(false);
    }
  };

  // Twilio SMS Password Reset - Verify OTP & Update Password
  const handleVerifyResetOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!resetOtpCode.trim() || (resetOtpCode.trim().length !== 4 && resetOtpCode.trim().length !== 6)) {
      setError("Please enter a valid verification code.");
      return;
    }

    if (!newPassword.trim() || newPassword.trim().length < 8) {
      setError("Please enter a new password (at least 8 characters).");
      return;
    }

    const passwordCheck = validatePasswordStrength(newPassword);
    if (!passwordCheck.isValid) {
      setError(passwordCheck.message);
      return;
    }

    const fullPhone = resetPhone.trim().startsWith("+") ? resetPhone.trim() : "+91" + resetPhone.trim();

    setLoading(true);

    try {
      console.log("Verifying Twilio Reset OTP on backend for:", fullPhone);
      const res = await fetch("/api/twilio/verify-reset-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone, code: resetOtpCode.trim() })
      });

      if (!res.ok) {
        throw new Error("Failed to communicate with password reset verify service.");
      }

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || "Incorrect or expired verification code.");
      }

      // Show incredible success notification
      setSuccess("Password has been reset successfully! Please sign in using your new credentials.");
      showToast("🎉 Password Reset Successful!", "success");
      
      // Return to sign in mode
      setTimeout(() => {
        setMode("signin");
        setAuthMethod("email");
        setResetPhoneStep("phone");
        setResetPhone("");
        setResetOtpCode("");
        setNewPassword("");
      }, 3000);
    } catch (err: any) {
      console.error("Password reset verify failed:", err);
      setError(err.message || "Incorrect verification code. Please check and try again.");
    } finally {
      setLoading(false);
    }
  };

  // Submit Standard Email Auth (Sign In or Sign Up)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!validateEmailFormat(email.trim())) {
      setError("Invalid Email");
      return;
    }

    if (mode === "signup") {
      const passwordCheck = validatePasswordStrength(password);
      if (!passwordCheck.isValid) {
        setError(passwordCheck.message);
        return;
      }
    } else {
      if (password.length < 6) {
        setError("Password must be at least 6 characters");
        return;
      }
    }

    setLoading(true);

    try {
      const displayName = role === "candidate" ? name : role === "consultancy" ? agencyName : (role === "employer" || role === "recruiter") ? companyName : name;
      if (mode === "signup") {
        if (!displayName.trim()) {
          throw new Error(`Please specify your ${role === "candidate" ? "Full Name" : role === "consultancy" ? "Agency Name" : (role === "employer" || role === "recruiter") ? "Company Name" : "Admin Name"}`);
        }

        if (password !== confirmPassword) {
          throw new Error("Password mismatch: passwords do not match.");
        }

        // Duplicate Email Check
        console.log("Checking duplicate email in Firestore...");
        try {
          const qEmail = query(collection(db, "users"), where("email", "==", email.trim()));
          const snapEmail = await getDocs(qEmail);
          if (!snapEmail.empty) {
            throw new Error("Email already exists");
          }
        } catch (dbErr: any) {
          console.warn("[AuthModal] Pre-emptive duplicate email check skipped or failed:", dbErr);
          if (dbErr.message === "Email already exists") {
            throw dbErr;
          }
        }

        console.log("Creating user...");
        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        console.log("User creation success:", userCredential);
        const fbUser = userCredential.user;

        console.log("Updating user profile display name:", displayName);
        await updateProfile(fbUser, { displayName });

        console.log("Initializing user Firestore collections & profile for role:", role);
        const userProfile = await initializeUserCollectionsAndDocs(fbUser, role, displayName);

        // Track Lead Attribution and create CRM lead entry
        try {
          await trackLeadSubmission({
            uid: fbUser.uid,
            name: displayName,
            email: email.trim(),
            role: role
          });
        } catch (leadErr) {
          console.warn("[AuthModal] Lead attribution capture warning:", leadErr);
        }

        console.log("Registration successfully finalized. User Profile:", userProfile);
        setSuccess("Account provisioned successfully!");
        onAuthSuccess(userProfile);
        onClose();
      } else {
        console.log("Signing in user...");
        const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        console.log("Sign-in success:", userCredential);
        const fbUser = userCredential.user;
        setSuccess("Sign-In successful!");
        await handlePostAuth(fbUser);
      }
    } catch (err: any) {
      setError(translateError(err));
    } finally {
      setLoading(false);
    }
  };

  // Complete Profile (Social fallback)
  const handleCompleteProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempFbUser) return;

    setError("");
    setSuccess("");

    const displayName = role === "candidate" ? name : role === "consultancy" ? agencyName : (role === "employer" || role === "recruiter") ? companyName : name;
    if (!displayName.trim()) {
      setError(`Please enter your ${role === "candidate" ? "Name" : role === "consultancy" ? "Agency Name" : (role === "employer" || role === "recruiter") ? "Company Name" : "Admin Name"}`);
      return;
    }

    setLoading(true);
    try {
      console.log("Updating user profile display name:", displayName);
      await updateProfile(tempFbUser, { displayName });

      console.log("Initializing user collections and profile document...");
      const userProfile = await initializeUserCollectionsAndDocs(tempFbUser, role, displayName);

      setSuccess("Profile settings saved! Welcome aboard.");
      onAuthSuccess(userProfile);
      onClose();
    } catch (err: any) {
      setError(translateError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-2xl">
      {/* Hidden reCAPTCHA anchor */}
      <div id="recaptcha-container" className="hidden"></div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.93, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: -10 }}
        transition={{ type: "spring", damping: 25, stiffness: 160 }}
        className="relative w-full max-w-lg bg-black/60 rounded-[28px] overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(59,130,246,0.15)] backdrop-blur-3xl flex flex-col max-h-[92vh] text-white"
        id="auth-modal-container"
      >
        {/* Background Gradients */}
        <div className="absolute inset-0 pointer-events-none z-0 opacity-20">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-600 rounded-full blur-[100px]"></div>
        </div>

        {/* Laser scanner vertical sweep bar */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-blue-500/60 to-transparent pointer-events-none animate-scan-laser z-20 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />

        {/* Fine Bevel Lines */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/15 to-transparent pointer-events-none z-20" />

        {/* Header */}
        <div className="relative z-10 p-5.5 border-b border-white/5 flex items-center justify-between bg-white/[0.01]">
          <div className="flex items-center space-x-3">
            {/* Rotating AI microchip */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 18, ease: "linear" }}
              className="relative w-8 h-8 flex items-center justify-center shrink-0 bg-blue-500/10 rounded-lg border border-blue-500/25 shadow-[0_0_15px_rgba(59,130,246,0.2)]"
            >
              <svg className="w-5 h-5 text-blue-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                <rect x="5" y="5" width="14" height="14" rx="2" />
                <path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4M9 9h6v6H9z" />
              </svg>
              <div className="absolute w-1.5 h-1.5 rounded-full bg-blue-300 animate-ping" />
            </motion.div>

            <span className="font-display font-black text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-100 to-gray-300">
              {mode === "signin" && "Welcome back to AIJobs"}
              {mode === "signup" && "Create your Workspace"}
              {mode === "phone-otp" && "SMS OTP Authentication"}
              {mode === "forgot-password" && "Dispatch Reset Email"}
              {mode === "complete-profile" && "Complete onboarding Profile"}
            </span>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-gray-400 hover:text-white transition-all cursor-pointer border border-transparent hover:border-white/5"
            id="close-auth-modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container */}
        <div className="relative z-10 overflow-y-auto p-6 space-y-5 flex-1">
          {/* Notifications */}
          {!isFirebaseConfigured && (
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl text-xs text-yellow-300 flex items-start space-x-2.5 animate-in slide-in-from-top-2">
              <AlertCircle className="w-4.5 h-4.5 mt-0.5 shrink-0 text-yellow-400" />
              <div className="space-y-1">
                <span className="font-bold text-yellow-200 block">Firebase Configuration Warning</span>
                <p className="text-gray-300 leading-relaxed text-[11px]">
                  {firebaseConfigError || "Firebase configuration is incomplete. Standard authentication may fail. Please verify your Firebase project credentials."}
                </p>
              </div>
            </div>
          )}
          {error && (
            <div className="p-3 bg-red-500/15 border border-red-500/30 rounded-xl text-xs text-red-300 flex items-start space-x-2 animate-in slide-in-from-top-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
          )}
          {success && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-start space-x-2 animate-in slide-in-from-top-2">
              <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
              <span>{success}</span>
            </div>
          )}

          {/* Views */}
          {mode === "complete-profile" ? (
            /* ===================================== */
            /* COMPLETE ONBOARDING PROFILE VIEW      */
            /* ===================================== */
            <form onSubmit={handleCompleteProfileSubmit} className="space-y-4">
              <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300">
                ✨ Authenticated successfully! Please choose your preferred account role and set your display name to complete onboarding.
              </div>

              {/* Role Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                  Register Profile As:
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { id: "candidate", title: "Candidate", icon: User, desc: "Search jobs & AI prep", color: "hover:border-indigo-500 hover:text-indigo-300" },
                    { id: "consultancy", title: "Consultancy Application", icon: Shield, desc: "Staffing & agency tools", color: "hover:border-purple-500 hover:text-purple-300" }
                  ].map((item) => {
                    const Icon = item.icon;
                    const isSel = role === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setRole(item.id as any)}
                        className={`p-3 rounded-xl flex flex-col items-left text-left border text-xs gap-1.5 transition-all duration-300 cursor-pointer ${
                          isSel
                            ? "bg-indigo-600/20 text-indigo-300 border-indigo-500/80 shadow-md"
                            : "bg-white/5 text-gray-400 border-white/5 " + item.color
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <Icon className={`w-4 h-4 ${isSel ? "text-indigo-400" : "text-gray-500"}`} />
                          {isSel && <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full"></div>}
                        </div>
                        <div>
                          <p className="font-bold text-white">{item.title}</p>
                          <p className="text-[10px] text-gray-400 font-normal leading-tight mt-0.5">{item.desc}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Inputs based on role */}
              <div className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-medium text-gray-300 mb-1">
                    {role === "candidate" ? "Your Full Name" : role === "consultancy" ? "Agency / Consultancy Name" : role === "employer" ? "Company Name" : "Admin Display Name"}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                    <input
                      type="text"
                      value={role === "candidate" ? name : role === "consultancy" ? agencyName : role === "employer" ? companyName : name}
                      onChange={(e) => {
                        if (role === "candidate" || role === "admin") setName(e.target.value);
                        else if (role === "consultancy") setAgencyName(e.target.value);
                        else setCompanyName(e.target.value);
                      }}
                      required
                      className="w-full pl-9 pr-4 py-2 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                      placeholder={role === "candidate" ? "e.g. Aryan Sharma" : role === "consultancy" ? "e.g. Nexus Talent Partners" : "e.g. Google AI Labs"}
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-4 py-2.5 px-4 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:to-pink-600 text-sm font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center justify-center space-x-2 text-white shadow-lg cursor-pointer"
              >
                <span>{loading ? "Finalizing Workspace..." : "Access My Workspace"}</span>
              </button>
            </form>
          ) : mode === "forgot-password" ? (
            /* ===================================== */
            /* FORGOT PASSWORD DUAL-METHOD VIEW      */
            /* ===================================== */
            <div className="space-y-4">
              {/* Method Selector Tabs */}
              <div className="flex bg-white/5 rounded-xl p-1 border border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setResetMethod("email");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    resetMethod === "email" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                >
                  Email Reset
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setResetMethod("phone");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    resetMethod === "phone" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                >
                  Mobile SMS OTP
                </button>
              </div>

              {resetMethod === "email" ? (
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <div className="text-xs text-gray-400 mb-2 leading-relaxed">
                    Provide your account email address and we will dispatch a secure link to reset your credentials.
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-300 mb-1">Registered Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full pl-9 pr-4 py-2 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                        placeholder="you@example.com"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <button
                      type="button"
                      onClick={() => setMode("signin")}
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back to Sign In</span>
                    </button>

                    <button
                      type="submit"
                      disabled={loading}
                      className="py-2 px-5 bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center space-x-1 text-white shadow-md cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>{loading ? "Dispatching..." : "Send Reset Link"}</span>
                    </button>
                  </div>
                </form>
              ) : (
                /* Twilio Phone OTP password reset form */
                <form onSubmit={resetPhoneStep === "phone" ? handleSendResetOtp : handleVerifyResetOtp} className="space-y-4">
                  {resetPhoneStep === "phone" ? (
                    <>
                      <div className="text-xs text-gray-400 mb-2 leading-relaxed">
                        Enter your mobile number below. We will send a security OTP verification code via Twilio Verify.
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-300 mb-1">Indian Mobile Number (+91)</label>
                        <div className="relative flex">
                          <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-white/10 bg-white/5 text-gray-400 text-sm">
                            +91
                          </span>
                          <input
                            type="tel"
                            value={resetPhone.replace(/^\+91/, "")}
                            onChange={(e) => setResetPhone("+91" + e.target.value.replace(/\D/g, ""))}
                            required
                            className="w-full pl-3 pr-4 py-2 text-sm bg-white/5 border border-white/10 rounded-r-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                            placeholder="98765 43210"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <button
                          type="button"
                          onClick={() => setMode("signin")}
                          className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>Back to Sign In</span>
                        </button>

                        <button
                          type="submit"
                          disabled={loading}
                          className="py-2 px-5 bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center space-x-1 text-white shadow-md cursor-pointer"
                        >
                          <Send className="w-3 h-3" />
                          <span>{loading ? "Sending OTP..." : "Send Reset Code"}</span>
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="text-xs text-gray-400 mb-2 leading-relaxed">
                        Enter the verification OTP code sent to your phone and specify your new account password.
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-300 mb-1">Verification Code</label>
                        <input
                          type="text"
                          value={resetOtpCode}
                          onChange={(e) => setResetOtpCode(e.target.value)}
                          maxLength={6}
                          required
                          className="w-full px-4 py-2 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all font-mono text-center tracking-widest"
                          placeholder="••••••"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-300 mb-1">New Password (Min 8 chars)</label>
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          required
                          className="w-full px-4 py-2 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                          placeholder="••••••••"
                        />
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <button
                          type="button"
                          onClick={() => setResetPhoneStep("phone")}
                          className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>Back to Phone</span>
                        </button>

                        <button
                          type="submit"
                          disabled={loading}
                          className="py-2 px-5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-xs font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center space-x-1 text-white shadow-md cursor-pointer"
                        >
                          <CheckSquare className="w-3 h-3" />
                          <span>{loading ? "Verifying..." : "Reset Password"}</span>
                        </button>
                      </div>
                    </>
                  )}
                </form>
              )}
            </div>
          ) : (
            /* ===================================== */
            /* EMAIL & MOBILE OTP UNIFIED VIEW       */
            /* ===================================== */
            <div className="space-y-4">
              {/* Toggle 1: Sign In vs Sign Up */}
              <div className="flex bg-white/5 rounded-xl p-1 border border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setMode("signin");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    mode === "signin" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode("signup");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    mode === "signup" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                >
                  Create Account
                </button>
              </div>

              {/* Toggle 2: Email vs Phone OTP */}
              <div className="flex bg-white/5 rounded-xl p-1 border border-white/5">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMethod("email");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    authMethod === "email" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                  id="tab-email-auth"
                >
                  {mode === "signin" ? "Email Login" : "Register using Email"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMethod("phone");
                    setPhoneStep("phone");
                    setError("");
                    setSuccess("");
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    authMethod === "phone" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-gray-400 hover:text-white"
                  }`}
                  id="tab-phone-auth"
                >
                  {mode === "signin" ? "Mobile OTP Login" : "Register using Mobile"}
                </button>
              </div>

              {/* Registration Role Selection Card Array */}
              {mode === "signup" && (
                <div className="space-y-2 animate-in fade-in duration-200">
                  <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider font-mono">
                    I Want To Register As:
                  </label>
                  <div className="grid grid-cols-2 gap-2.5">
                    {[
                      { id: "candidate", title: "Candidate", icon: User, desc: "Search jobs & AI prep", color: "hover:border-indigo-500 hover:text-indigo-300" },
                      { id: "consultancy", title: "Consultancy Application", icon: Shield, desc: "Staffing & agency portal", color: "hover:border-purple-500 hover:text-purple-300" }
                    ].map((item) => {
                      const Icon = item.icon;
                      const isSel = role === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setRole(item.id as any)}
                          className={`p-3 rounded-xl flex flex-col items-left text-left border text-xs gap-1.5 transition-all duration-300 cursor-pointer ${
                            isSel
                              ? "bg-indigo-600/20 text-indigo-300 border-indigo-500/80 shadow-md animate-none"
                              : "bg-white/5 text-gray-400 border-white/5 " + item.color
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <Icon className={`w-4 h-4 ${isSel ? "text-indigo-400" : "text-gray-500"}`} />
                            {isSel && <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-pulse"></div>}
                          </div>
                          <div>
                            <p className="font-bold text-white">{item.title}</p>
                            <p className="text-[10px] text-gray-400 font-normal leading-tight mt-0.5">{item.desc}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* AUTHENTICATION FORMS BODY */}
              {authMethod === "email" ? (
                /* ===================================== */
                /* EMAIL LOGIN & REGISTRATION FORMS      */
                /* ===================================== */
                <form onSubmit={handleSubmit} className="space-y-3.5">
                  {mode === "signup" && (
                    <div className="animate-in fade-in duration-200">
                      <label className="block text-xs font-medium text-gray-300 mb-1">
                        {role === "candidate" ? "Full Name" : role === "consultancy" ? "Consultancy Name" : (role === "employer" || role === "recruiter") ? "Company / Agency Name" : "Admin Display Name"}
                      </label>
                      <div className="relative">
                        {role === "candidate" && <User className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                        {role === "consultancy" && <Building2 className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                        {(role === "employer" || role === "recruiter") && <Briefcase className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                        {(role === "admin" || role === "superadmin") && <ShieldCheck className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                        <input
                          type="text"
                          value={(role === "candidate" || role === "admin" || role === "superadmin") ? name : role === "consultancy" ? agencyName : companyName}
                          onChange={(e) => {
                            if (role === "candidate" || role === "admin" || role === "superadmin") setName(e.target.value);
                            else if (role === "consultancy") setAgencyName(e.target.value);
                            else setCompanyName(e.target.value);
                          }}
                          required
                          className="w-full pl-9 pr-4 py-2.5 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                          placeholder={role === "candidate" ? "e.g. Aryan Sharma" : role === "consultancy" ? "e.g. Nexus Talent" : "e.g. Google Labs"}
                          id="auth-name-input"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-gray-300 mb-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full pl-9 pr-4 py-2.5 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                        placeholder="you@example.com"
                        id="auth-email-input"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-medium text-gray-300">Password</label>
                      {mode === "signin" && (
                        <button
                          type="button"
                          onClick={() => setMode("forgot-password")}
                          className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium cursor-pointer"
                          id="auth-forgot-pwd"
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                      <input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full pl-9 pr-10 py-2.5 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                        placeholder="••••••••"
                        id="auth-password-input"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-3 text-gray-500 hover:text-white transition-all cursor-pointer animate-none"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {mode === "signup" && (
                    <div className="animate-in fade-in duration-200">
                      <label className="block text-xs font-medium text-gray-300 mb-1">Confirm Password</label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                        <input
                          type={showPassword ? "text" : "password"}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          required
                          className="w-full pl-9 pr-4 py-2.5 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                          placeholder="••••••••"
                          id="auth-confirm-password"
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full mt-3 py-2.5 px-4 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:from-indigo-600 hover:to-pink-600 text-sm font-semibold rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-2 text-white cursor-pointer"
                    id="auth-submit-btn"
                  >
                    {mode === "signup" ? <UserPlus className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    <span>{loading ? "Processing..." : mode === "signup" ? "Register with Email" : "Access Workspace"}</span>
                  </button>
                </form>
              ) : (
                /* ===================================== */
                /* MOBILE PHONE OTP LOGIN & REGISTER      */
                /* ===================================== */
                <div className="space-y-4">
                  {phoneStep === "phone" ? (
                    <form onSubmit={handleSendOtp} className="space-y-4">
                      {mode === "signup" && (
                        <div className="animate-in fade-in duration-200 space-y-3">
                          <div>
                            <label className="block text-xs font-medium text-gray-300 mb-1">
                              {role === "candidate" ? "Full Name" : role === "consultancy" ? "Consultancy Name" : role === "employer" ? "Company Name" : "Admin Display Name"}
                            </label>
                            <div className="relative">
                              {role === "candidate" && <User className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                              {role === "consultancy" && <Building2 className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                              {role === "employer" && <Briefcase className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                              {role === "admin" && <ShieldCheck className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />}
                              <input
                                type="text"
                                value={role === "candidate" || role === "admin" ? name : role === "consultancy" ? agencyName : companyName}
                                onChange={(e) => {
                                  if (role === "candidate" || role === "admin") setName(e.target.value);
                                  else if (role === "consultancy") setAgencyName(e.target.value);
                                  else setCompanyName(e.target.value);
                                }}
                                required
                                className="w-full pl-9 pr-4 py-2.5 text-sm bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all"
                                placeholder={role === "candidate" ? "e.g. Aryan Sharma" : role === "consultancy" ? "e.g. Nexus Talent" : "e.g. Google Labs"}
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      <div>
                        <label className="block text-xs font-medium text-gray-300 mb-1">Mobile Phone Number</label>
                        <div className="flex">
                          {/* Country Code Picker Select */}
                          <select
                            value={countryCode}
                            onChange={(e) => setCountryCode(e.target.value)}
                            className="bg-gray-900 border border-white/10 rounded-l-xl px-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-sans cursor-pointer max-w-[130px]"
                          >
                            {COUNTRY_CODES.map((item) => (
                              <option key={item.code} value={item.code} className="bg-gray-950 text-white text-xs">
                                {item.label}
                              </option>
                            ))}
                          </select>

                          {/* Phone input */}
                          <input
                            type="tel"
                            value={rawPhoneNumber}
                            onChange={(e) => setRawPhoneNumber(e.target.value.replace(/\D/g, ""))}
                            required
                            className="flex-1 pl-3 pr-4 py-2.5 text-sm bg-white/5 border-y border-r border-white/10 rounded-r-xl focus:outline-none focus:border-indigo-500 text-white font-mono transition-all"
                            placeholder="9876543210"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-sm font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center justify-center space-x-2 text-white cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                        <span>{loading ? "Checking & sending SMS..." : "Send Verification OTP"}</span>
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleVerifyOtp} className="space-y-4 animate-in fade-in duration-300">
                      <div className="p-3 bg-indigo-950/40 border border-indigo-900/30 rounded-xl flex items-start space-x-2 text-xs text-indigo-200">
                        <Phone className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5 animate-pulse" />
                        <p>SMS verification code routed to <span className="font-bold text-white">{countryCode} {rawPhoneNumber}</span>. Enter code below.</p>
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-medium text-gray-300 text-center mb-1">Enter 6-Digit OTP</label>
                        <div className="flex justify-between gap-2 max-w-sm mx-auto" onPaste={handlePaste}>
                          {otpDigits.map((digit, idx) => (
                            <input
                              key={idx}
                              id={`otp-input-${idx}`}
                              type="text"
                              maxLength={1}
                              value={digit}
                              onChange={(e) => handleDigitChange(idx, e.target.value)}
                              onKeyDown={(e) => handleKeyDown(idx, e)}
                              className="w-12 h-12 text-center text-xl font-bold bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-indigo-500 text-white transition-all font-mono focus:ring-1 focus:ring-indigo-500"
                              autoFocus={idx === 0}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs text-gray-400 px-1 pt-1">
                        <span>Didn't receive SMS?</span>
                        {countdown > 0 ? (
                          <span className="text-gray-500">Resend in <strong className="text-indigo-400 font-mono">{countdown}s</strong></span>
                        ) : (
                          <button
                            type="button"
                            onClick={handleResendOtp}
                            className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
                          >
                            Resend Code
                          </button>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-4">
                        <button
                          type="button"
                          onClick={() => setPhoneStep("phone")}
                          className="text-xs text-gray-400 hover:text-white flex items-center space-x-1 cursor-pointer"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                          <span>Change Number</span>
                        </button>

                        <button
                          type="submit"
                          disabled={loading}
                          className="py-2.5 px-6 bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-600 text-xs font-bold rounded-xl transition-all disabled:opacity-50 text-white shadow-md cursor-pointer"
                        >
                          <span>{loading ? "Verifying OTP..." : mode === "signup" ? "Verify OTP & Register" : "Verify OTP & Login"}</span>
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* Social/Google Button */}
              <div className="pt-2">
                <button
                  onClick={handleGoogleLogin}
                  disabled={loading}
                  className="py-2.5 px-3 border border-white/10 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all cursor-pointer text-white disabled:opacity-50 w-full"
                  id="google-login-btn"
                >
                  <svg className="w-4 h-4 text-red-400 shrink-0" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12.24 10.285V13.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.866-3.577-7.866-8s3.536-8 7.866-8c2.46 0 4.105 1.025 5.047 1.926l2.427-2.334C17.955 2.192 15.34 1 12.24 1c-6.075 0-11 4.925-11 11s4.925 11 11 11c6.34 0 10.564-4.437 10.564-10.715 0-.724-.078-1.282-.172-1.71h-10.392z" />
                  </svg>
                  <span>Google Sign-In</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
